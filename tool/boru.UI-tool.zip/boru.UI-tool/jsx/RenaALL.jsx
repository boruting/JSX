﻿//#target photoshop
dodo();
function dodo() {

    alert("aaaaaa");

}
