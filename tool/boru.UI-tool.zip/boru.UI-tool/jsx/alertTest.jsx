﻿function alertTest (txt){

    alert("测试   " + txt);

}