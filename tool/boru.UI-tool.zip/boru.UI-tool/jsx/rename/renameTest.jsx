﻿var extensionPath = "C:/Program Files (x86)/Common Files/Adobe/CEP/extensions/boru.UI-tool";
 $.evalFile(extensionPath + "/jsx/rename/A.jsx");
var naTest = function (){

    //$.evalFile(extensionPath + "/jsx/rename/A.jsx");
    //$.global.abc=abc;
    abc("789");

} 
naTest();